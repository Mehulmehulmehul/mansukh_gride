<?php
/**
 * Grid Module registration.
 * @category  Mansukh
 * @package   Mansukh_Grid
 * @author    Mansukh
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mansukh_Grid',
    __DIR__
);
